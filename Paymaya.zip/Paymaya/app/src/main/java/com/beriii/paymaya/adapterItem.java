package com.beriii.paymaya;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class adapterItem extends RecyclerView.Adapter<itemViewHolder> {

    Context context;
    List<itemRecyclerView> itemRecyclerViewList;


    public adapterItem(Context context, List<itemRecyclerView> itemRecyclerViewList){
        this.context = context;
        this.itemRecyclerViewList = itemRecyclerViewList;
    }

    @NonNull
    @Override
    public itemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new itemViewHolder(LayoutInflater.from(context).inflate(R.layout.transaction_component, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull itemViewHolder holder, int position) {
        Log.i("FindMeError2", itemRecyclerViewList.get(position).getItemName());
        holder.itemNameText.setText(itemRecyclerViewList.get(position).getItemName());
        holder.amountText.setText(itemRecyclerViewList.get(position).getAmount());
        holder.dateText.setText(itemRecyclerViewList.get(position).getDate());
        holder.referenceIDText.setText(itemRecyclerViewList.get(position).getReferenceID());
        holder.detailsText.setText(itemRecyclerViewList.get(position).getDetail());
    }

    @Override
    public int getItemCount() {
        return itemRecyclerViewList.size();
    }
}
