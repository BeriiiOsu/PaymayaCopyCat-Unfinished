package com.beriii.paymaya;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class itemViewHolder extends RecyclerView.ViewHolder {

    TextView detailsText, itemNameText, dateText, amountText, referenceIDText;


    public itemViewHolder(@NonNull View itemView) {
        super(itemView);
        detailsText = itemView.findViewById(R.id.detailsText);
        itemNameText = itemView.findViewById(R.id.itemNameText);
        dateText = itemView.findViewById(R.id.dateText);
        amountText = itemView.findViewById(R.id.amountText);
        referenceIDText = itemView.findViewById(R.id.referenceIDText);
    }
}
