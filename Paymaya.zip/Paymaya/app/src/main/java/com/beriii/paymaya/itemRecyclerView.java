package com.beriii.paymaya;

public class itemRecyclerView {

    String itemName;
    String detail;
    String amount;
    String date;
    String referenceID;


    public itemRecyclerView(String itemName, String detail, String amount, String date, String referenceID) {
        this.itemName = itemName;
        this.detail = detail;
        this.amount = amount;
        this.date = date;
        this.referenceID = referenceID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public String getReferenceID() {
        return referenceID;
    }

    public void setReferenceID(String referenceID) {
        this.referenceID = referenceID;
    }
}
