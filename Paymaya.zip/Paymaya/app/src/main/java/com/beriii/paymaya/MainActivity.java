package com.beriii.paymaya;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RelativeLayout walletBtn, savingsBtn, creditBtn, loansBtn, cardBtn;
    TextView walletText, savingstText, creditText, loansText, cardText;


    FrameLayout firstContent, secondContent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        walletBtn = findViewById(R.id.walletBtn);
        walletText = findViewById(R.id.walletText);


        List<itemRecyclerView> items = new ArrayList<>();

        items.add(new itemRecyclerView("Maya Crypto",
                "Purchased",
                "- ₱ 9583.05",
                "2024-12-28, 09:45 AM",
                "43ghg2h4hg"));

        items.add(new itemRecyclerView("Maya Crypto",
                "Purchased",
                "- ₱ 48936.05",
                "2024-12-29, 02:14 AM",
                "bfdhdrd34563fr"));




        savingsBtn = findViewById(R.id.savingsBtn);
        savingstText = findViewById(R.id.savingstText);

        creditBtn = findViewById(R.id.creditBtn);
        creditText = findViewById(R.id.creditText);

        loansBtn = findViewById(R.id.loansBtn);
        loansText = findViewById(R.id.loansText);

        cardBtn = findViewById(R.id.cardBtn);
        cardText = findViewById(R.id.cardText);


        //layouts
        firstContent = findViewById(R.id.walletContent);
        secondContent = findViewById(R.id.transactionContent);

        View wallet = getLayoutInflater().inflate(R.layout.activity_wallet, firstContent, false);
        firstContent.addView(wallet);

        View transac = getLayoutInflater().inflate(R.layout.activity_transaction, secondContent, false);
        secondContent.addView(transac);


        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new adapterItem(getApplicationContext(), items));


        walletBtn.setBackgroundResource(R.drawable.dark_button);
        walletText.setTextColor(getResources().getColor(R.color.white));

        walletBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setWalletBtn();
            }
        });

        savingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setSavingsBtn();
            }
        });

        creditBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setCreditBtn();
            }
        });

        loansBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setLoansBtn();
            }
        });

        cardBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setCardBtn();
            }
        });


    }







    private void setWalletBtn(){
        View wallet = getLayoutInflater().inflate(R.layout.activity_wallet, firstContent, false);
        firstContent.addView(wallet);

        View transac = getLayoutInflater().inflate(R.layout.activity_transaction, secondContent, false);
        secondContent.addView(transac);


        walletBtn.setBackgroundResource(R.drawable.dark_button);
        walletText.setTextColor(getResources().getColor(R.color.white));

        savingsBtn.setBackground(null);
        savingstText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        creditBtn.setBackground(null);
        creditText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        loansBtn.setBackground(null);
        loansText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        cardBtn.setBackground(null);
        cardText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));



        List<itemRecyclerView> items = new ArrayList<>();

        items.add(new itemRecyclerView("Maya Crypto",
                "Purchased",
                "- ₱ 9583.05",
                "2024-12-28, 09:45 AM",
                "43ghg2h4hg"));


        items.add(new itemRecyclerView("Maya Crypto",
                "Purchased",
                "- ₱ 48936.05",
                "2024-12-29, 02:14 AM",
                "bfdhdrd34563fr"));



        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new adapterItem(getApplicationContext(), items));
    }

    private void setSavingsBtn(){

        firstContent.removeAllViews();
        //new view
        View savingsContent = getLayoutInflater().inflate(R.layout.activity_savings,firstContent, false);
        firstContent.addView(savingsContent);
        secondContent.removeAllViews();



        walletBtn.setBackground(null);
        walletText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        savingsBtn.setBackgroundResource(R.drawable.dark_button);
        savingstText.setTextColor(getResources().getColor(R.color.white));

        creditBtn.setBackground(null);
        creditText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        loansBtn.setBackground(null);
        loansText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        cardBtn.setBackground(null);
        cardText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));
    }

    private void setCreditBtn(){
        firstContent.removeAllViews();
        //new view
        View creditContent = getLayoutInflater().inflate(R.layout.credit,firstContent, false);
        firstContent.addView(creditContent);

        secondContent.removeAllViews();
        walletBtn.setBackground(null);
        walletText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        savingsBtn.setBackground(null);
        savingstText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        creditBtn.setBackgroundResource(R.drawable.dark_button);
        creditText.setTextColor(getResources().getColor(R.color.white));

        loansBtn.setBackground(null);
        loansText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        cardBtn.setBackground(null);
        cardText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));
    }

    private void setLoansBtn(){
        firstContent.removeAllViews();
        //new view
        View loan = getLayoutInflater().inflate(R.layout.loans,firstContent, false);
        firstContent.addView(loan);

        secondContent.removeAllViews();
        walletBtn.setBackground(null);
        walletText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        savingsBtn.setBackground(null);
        savingstText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        creditBtn.setBackground(null);
        creditText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        loansBtn.setBackgroundResource(R.drawable.dark_button);
        loansText.setTextColor(getResources().getColor(R.color.white));

        cardBtn.setBackground(null);
        cardText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));
    }

    private void setCardBtn(){
        firstContent.removeAllViews();
        //new view


        secondContent.removeAllViews();
        walletBtn.setBackground(null);
        walletText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        savingsBtn.setBackground(null);
        savingstText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        creditBtn.setBackground(null);
        creditText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        loansBtn.setBackground(null);
        loansText.setTextColor(getResources().getColor(androidx.cardview.R.color.cardview_dark_background));

        cardBtn.setBackgroundResource(R.drawable.dark_button);
        cardText.setTextColor(getResources().getColor(R.color.white));
    }

}