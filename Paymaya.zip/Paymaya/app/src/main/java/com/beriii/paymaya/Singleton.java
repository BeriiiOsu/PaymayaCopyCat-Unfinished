package com.beriii.paymaya;

public class Singleton {
    private static Singleton instance;
    String firstName, middleName, lastName;
    String email, pass;

    public Singleton(){

    }

    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }


    public void setEmail(String email) {
        this.email = email;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getEmail() {
        return email;
    }

    public String getPass() {
        return pass;
    }

    public void setFirstName(String firstName){this.firstName = firstName;}

    public String getFirstName(){return firstName;}

    public void setMiddleName(String middleName){this.middleName = middleName;}

    public String getMiddleName(){return middleName;}

    public void setLastName(String lastName){this.lastName = lastName;}

    public String getLastName(){return lastName;}



}
