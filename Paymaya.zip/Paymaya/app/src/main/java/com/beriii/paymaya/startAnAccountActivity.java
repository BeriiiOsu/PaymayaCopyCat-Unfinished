package com.beriii.paymaya;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class startAnAccountActivity extends AppCompatActivity {


    RelativeLayout backStartAccountBtn;
    EditText firstNameTxt, middleNameTxt, lastNameTxt;
    RelativeLayout startContinueBtn;
    TextView backStartBtnToLoginBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_start_an_account);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        backStartAccountBtn = findViewById(R.id.backStartAccountBtn);
        firstNameTxt = findViewById(R.id.firstNameTxt);
        middleNameTxt = findViewById(R.id.middleNameTxt);
        lastNameTxt = findViewById(R.id.lastNameTxt);
        startContinueBtn = findViewById(R.id.startContinueBtn);
        backStartBtnToLoginBtn = findViewById(R.id.backStartBtnToLoginBtn);


        backStartAccountBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             startActivity(new Intent(startAnAccountActivity.this, startingActivity.class));
            }
        });

        backStartBtnToLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(startAnAccountActivity.this, loginActivity.class));
            }
        });

        startContinueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String firstName = firstNameTxt.getText().toString().trim();
                String middleName = middleNameTxt.getText().toString().trim();
                String lastName = lastNameTxt.getText().toString().trim();


                if(firstName.isEmpty() || middleName.isEmpty() || lastName.isEmpty()){
                    Toast.makeText(getApplicationContext(), "All fields are required!", Toast.LENGTH_SHORT).show();
                }else{
                    Singleton s = Singleton.getInstance();

                    s.setFirstName(firstName);
                    s.setMiddleName(middleName);
                    s.setLastName(lastName);

                    startActivity(new Intent(startAnAccountActivity.this, startAnAccountPart2Activity.class));
                }
            }
        });

    }
}